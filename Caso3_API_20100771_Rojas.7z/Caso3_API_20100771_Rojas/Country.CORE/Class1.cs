﻿namespace Country.CORE
{
    public class Class1
    {

    }
}