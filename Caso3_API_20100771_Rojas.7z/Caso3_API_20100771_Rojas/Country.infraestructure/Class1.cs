﻿namespace Country.infraestructure
{
    public class Class1
    {

    }
}